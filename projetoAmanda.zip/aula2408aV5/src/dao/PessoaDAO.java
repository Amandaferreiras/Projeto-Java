package dao;
import beans.Clinica;
import beans.Pessoa;
import java.sql.Connection;
import conexao.Conexao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PessoaDAO {
    private Connection conn;
    
    public PessoaDAO(){
        this.conn = Conexao.getConexao();
    }
    
    public void inserir(Pessoa p) throws Exception{
        String sql = "INSERT INTO pessoa(nomepessoa, ddd, clinicaid) VALUES(?, ?, ?)";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, p.getNomepessoa());
            stmt.setDouble(2, p.getDdd());
            stmt.setInt(3, p.getClinicaid().getId());
            stmt.execute();
        } catch (Exception e) {
            throw new Exception("Erro ao inserir pessoa: " + e.getMessage());
        }
    }
    
    public Pessoa getPessoa(int id) throws Exception{
        String sql = "SELECT * FROM pessoa WHERE id = ?";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            rs.first();
            
            Pessoa p = new Pessoa();
            p.setId(rs.getInt("id"));
            p.setNomepessoa(rs.getString("nomepessoa"));
            p.setDdd(rs.getDouble("Ddd"));
            
            Clinica c = new Clinica();
            c.setId(rs.getInt("clinicaid"));
            p.setClinicaid(c);
            
            return p;
        } catch (Exception e) {
            throw new Exception("Erro ao procurar pessoa: " + e.getMessage());
        }
    }
}
