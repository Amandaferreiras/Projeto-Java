package dao;


import beans.Clinica;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public class ClinicaDAO {
    private Connection conn;
    
    public ClinicaDAO() {
        this.conn = Conexao.getConexao();
    }
    
    public void insert(Clinica c) throws Exception{
        String sql = "INSERT INTO clinica(tipomedico) VALUES (?)";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, c.getTipomedico());
            stmt.execute();
        } catch (Exception e) {
            throw new Exception("Erro ao inserir clinica: " + e.getMessage());
        }
    }
    
    public Clinica getClinica(int id) throws Exception{
        String sql = "SELECT * FROM clinica WHERE id = ?";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            rs.first();
            
            Clinica c = new Clinica();
            c.setId(rs.getInt("id"));
            c.setTipomedico(rs.getString("tipomedico"));
            
            return c;
        } catch (Exception e) {
            throw new Exception("Erro ao procurar por dados: " + e.getMessage());
        }
    }
    
    public void atualizar(Clinica c) throws Exception{
        String sql = "UPDATE clinica SET tipomedico = ? WHERE id = ?";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, c.getTipomedico());
            stmt.setInt(2, c.getId());
            stmt.execute();
        } catch (Exception e) {
            throw new Exception("Erro ao atualizar tipo de Médico especialista: " + e.getMessage());
        }
    }
    
    public void excluir(Clinica c) throws Exception{
        
        
        try {
            String sql = "DELETE clinica SET tipomedico = ? WHERE id = ?";
        } catch (Exception e) {
            throw new Exception("Erro ao excluir tipo de Médico especialista: " + e.getMessage());
        }
    }
    
    
    public List<Clinica> getClinica(String tipoMedico) throws Exception{
        List<Clinica> lista = new ArrayList();
        
        String sql = "SELECT * FROM clinica WHERE tipomedico LIKE ?";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, "%" + tipoMedico + "%");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Clinica c = new Clinica();
                c.setId(rs.getInt("id"));
                c.setTipomedico(rs.getString("tipomedico"));
                
                lista.add(c);
            }
            return lista;
        } catch (Exception e) {
            throw new Exception("Nenhuma clinica / tipo medico encontrado/a: " + e.getMessage());
        }
    }
    
}