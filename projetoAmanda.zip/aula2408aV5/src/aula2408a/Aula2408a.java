package aula2408a;


public class Aula2408a {


    public static void main(String[] args) {
        
    }
    
}
