package beans;


public class Clinica {
    private int id;
    private String tipomedico;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipomedico() {
        return tipomedico;
    }

    public void setTipomedico(String tipomedico) {
        this.tipomedico = tipomedico;
    }

 
    
    public String toString(){
        return this.tipomedico;
    }

    // cria esse método para saber como comparar 2 objetos "Categoria" na hora de
    // setar uma categoria na combo de categorias
    
    @Override
    public boolean equals(Object obj) {
        Clinica c = (Clinica) obj;
        return this.id == c.id;
    }
    
}
