package beans;


public class Pessoa {
    private int id;
    private String nomepessoa;
    private double ddd;
    private Clinica clinicaid;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomepessoa() {
        return nomepessoa;
    }

    public void setNomepessoa(String nomepessoa) {
        this.nomepessoa = nomepessoa;
    }

    public double getDdd() {
        return ddd;
    }

    public void setDdd(double ddd) {
        this.ddd = ddd;
    }

    public Clinica getClinicaid() {
        return clinicaid;
    }

    public void setClinicaid(Clinica clinicaid) {
        this.clinicaid = clinicaid;
    }

   
    
}
